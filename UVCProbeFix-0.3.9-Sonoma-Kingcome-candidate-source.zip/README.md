# UVCProbeFix

Lilu plugin for targeted recovery of USB UVC cameras whose video stream fails during PROBE/COMMIT negotiation.

This source fork adds a narrowly scoped workaround for the built-in Kingcome `2B7E:128F` camera on Intel x86_64 Hackintosh systems running macOS Sonoma 14.7.x (Darwin 23.6). The user's logs show MJPEG and YUY2 streams both fail at `GET_CUR Probe` with `kIOReturnOverrun` (`-536870168`) before any video packets arrive.

## Compatibility

| macOS | Darwin | Scope |
| --- | --- | --- |
| Sonoma 14.7.x | 23.6.x | UVC 1.5 `GET_CUR` 34-to-48 byte recovery for `2B7E:128F`; x86_64 only |
| Sequoia | 24.x | Existing Sequoia camera recovery |
| Tahoe | 25.x | Existing Tahoe camera recovery |

On Sonoma the plugin starts only the UVC 1.5 request-length module, then returns. The 0.3.9 candidate retains the synchronous class/interface GET_CUR retry and adds Kingcome-only SET_CUR handling for the measured 34-byte request. It copies the original 34-byte host payload into a 48-byte scratch buffer and appends the 14-byte suffix captured from a successful Windows SET_CUR transaction. It targets only VS_PROBE/VS_COMMIT (`wValue=0x0100/0x0200`), Kingcome `2B7E:128F`, streaming interface 1; other requests pass through unchanged. This source is an unbuilt candidate and requires target-side build review before installation. Unsupported kernel builds, missing symbols, or unexpected function prologues leave the hook inactive. Boot argument `-uvc15off` disables this module; `-uvcpoff` disables the plugin.

The user's latest Sonoma trace confirms a 34-byte descriptor-backed `GET_CUR Probe` fails with `kIOReturnOverrun` (`-536870168`) and zero bytes transferred. The 34-to-48 retry remains a candidate adaptation: it has not been built or physically validated on the target machine. It requires target-side compilation and hardware testing before it can be considered a working fix.

## Build

Build on an Intel Mac with full Xcode selected:

```sh
./Build.command
```

The script builds and audits the kext without installing it. It requires Lilu 1.7.2 and the pinned MacKernelSDK. The resulting ad-hoc signed kext should first be tested with a backed-up OpenCore EFI and the supplied `OpenCore-Kernel-Add-entry.plist`; use `MinKernel=23.6.0`, `MaxKernel=25.99.99`, and place it after Lilu in `Kernel -> Add`.

## Existing project behavior

The prior Sequoia and Tahoe recovery paths remain in the project. On Sonoma, only the new allowlisted UVC 1.5 request path is started; the legacy shared-cache patches are not invoked.

## License

BSD 3-Clause. See [LICENSE](LICENSE) and [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).
