# Changelog

## 0.3.9 (309)

- Add a Kingcome-only 34-to-48-byte synchronous SET_CUR Probe/Commit route for interface 1, based on the successful Windows USBPcap payload.
- Preserve the host's 34-byte request and append the measured 14-byte UVC 1.5 suffix; keep the existing GET_CUR retry.
- Candidate only: requires target-side build review and Photo Booth/OBS validation; do not install unless the build passes.

## 0.3.8 (308)

- Replace the descriptor-backed temporary transfer path with a raw 48-byte scratch buffer and bounded copy-back to the existing host descriptor, avoiding creation/completion of a temporary IOMemoryDescriptor.
- Candidate only: requires macOS target build and review before installation; not yet compiled or validated on hardware.

## 0.3.7 (307)

- Extend the allowlisted Sonoma Kingcome 34-to-48-byte Probe recovery to the descriptor-backed synchronous request path observed on the user's camera.
- Use a separate 48-byte input memory descriptor; copy back only after an exact complete transfer and verified 34-byte host-buffer copy.
- Keep the original raw-buffer path and the frozen Lenovo legacy recovery unchanged.

## 0.3.6 (306)

- Trace up to 32 Kingcome Probe/Commit `GET_CUR` requests with compact setup fields, buffer type, and original transfer result so enumeration traffic cannot exhaust the diagnostic limit.
- Use Lilu SYSTRACE at plugin startup, IOUSBHostFamily callback entry, and UVC 1.5 registration to report through both the system log and kernel backtrace channel.
- Preserve 0.3.5 request policy and transfer behavior.

## 0.3.5 (305)

- Add Sonoma UVC 1.5 startup, target callback, and request route status logs to identify why a loaded plugin does not recover the Kingcome camera stream.
- No USB request policy or transfer behavior changed from 0.3.4.

## 0.3.4 (304)

- Add an allowlisted UVC 1.5 `GET_CUR` 34-to-48 byte workaround for Kingcome `2B7E:128F` on Sonoma Darwin 23.6.x x86_64.
- Admit Sonoma through OpenCore from Darwin 23.6 and return early into the UVC 1.5 path; existing Sequoia/Tahoe recovery logic remains separate.
- Fail closed if the IOUSBHostFamily symbol or expected method prologue does not match.
- Mark the Sonoma/Kingcome port as a candidate adaptation pending target-side build and physical camera validation.

## 0.3.3 (303)

- Publish versioned GitHub Releases automatically after successful builds on `main`.

- Accept all Darwin `24.x` kernels for Sequoia and all Darwin `25.x` kernels for the Tahoe S145 recovery.
- Remove the Sequoia minor `0` and Tahoe minor `6` admission restrictions without changing patch bytes or fingerprint checks.
- Set the OpenCore kernel range to `24.0.0`–`25.99.99`.
- Identify the Lenovo S145 (Ice Lake) as the development target; other laptop models may require adaptation.

## 0.3.2 (302)

- Adapt the existing Tahoe Frame 4 to Frame 1, single-retry PROBE recovery to Sequoia 15.0 build `24A335`.
- Match the complete captured Sequoia method before applying its own instruction offsets and stack/register layout.
- Preserve the Tahoe patch bytes, recovery policy, and HP module.
- Admit the same kext through OpenCore on Darwin `24.0.0` through `25.6.0`, with exact runtime and fingerprint checks.
- Add native x86_64 patch execution, fingerprint rejection, byte-preservation, and retry-limit tests.
- Add GitHub Actions validation, Release builds, downloadable artifacts, and version-tag release automation.

Physical camera operation on Sequoia is awaiting hardware validation. The generic transport remains excluded from Release.
