# Sonoma Kingcome integration

Target: built-in Kingcome HD Camera `2B7E:128F`, Intel x86_64 Hackintosh, macOS 14.7.7 / Darwin 23.6.x.

## Evidence

- The device is already enumerated by Apple's UVC extension.
- macOS reports `bcdUSB 150` in the UVC probe trace.
- MJPEG and YUV422/YUY2 both fail at `GET_CUR Probe` with `IOUSBHostErrorDomain -536870168` (`kIOReturnOverrun`).
- The stream reports zero packets and zero frames.
- The Windows device reports one capture function (`MI_00`) and ordinary MJPG/YUY2 modes.

This matches the UVC 1.5 34-byte host request versus 48-byte response overrun class. The exact raw transfer length has not been captured on this camera, so this remains a well-supported hypothesis rather than a measured packet trace.

## Port details

The existing `UVC15ProbeOverrun` Lilu route is reused. The Kingcome allowlist entry is restricted to VID/PID `2B7E:128F`, interface 1, synchronous class/interface `GET_CUR` requests for VS_PROBE or VS_COMMIT with host length 34. Only that transaction is reissued as 48 bytes into a distinct temporary kernel buffer; the first 34 bytes are copied back after a full 48-byte response. Allocation failure or ineligible traffic uses Apple's original request path.

The module is admitted only on Sonoma Darwin minor 6 (covering the reported 14.7.x line) and the original Tahoe 25.6 target. The symbol selector and prologue checks remain fail-closed. A missing symbol, mismatched prologue, incomplete response, or other request leaves camera streaming unchanged by the patch.

Version 0.3.6 emits startup and callback traces through Lilu's SYSTRACE path and traces up to 32 Kingcome Probe/Commit `GET_CUR` requests. Version 0.3.7 added a temporary descriptor path that caused a panic during OBS use and must not be installed. Version 0.3.8 enabled a raw 48-byte GET_CUR retry. The new diagnostics show GET_CUR succeeds but SET_CUR fails before video packets start. Windows USBPcap confirms 48-byte SET_CUR payloads for Probe and Commit. Version 0.3.9 is an unbuilt candidate that appends the measured UVC 1.5 suffix to the host 34-byte SET_CUR request; it requires target build review before installation.

## Validation state

Source changes are prepared, but this Windows workspace cannot run Xcode, inspect the target Sonoma kernel collection, compile the kext, or test the internal camera. Build with the project's `Build.command` on the target Intel Mac and confirm the hook activation log before testing the camera. If the hook declines the method prologue or symbol, do not bypass the checks; collect the resulting build and boot logs for a Sonoma-specific ABI adjustment.
