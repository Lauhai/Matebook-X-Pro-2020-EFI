// UVC 1.5 HP control-request overrun recovery. Independent of the Lenovo legacy path.
#pragma once
#include <stdint.h>
#include <stddef.h>

namespace UVC15 {
static constexpr uint16_t kHPVendor = 0x04F2;
static constexpr uint16_t kHPProduct = 0xB6BF;
static constexpr uint16_t kKingcomeVendor = 0x2B7E;
static constexpr uint16_t kKingcomeProduct = 0x128F;
static constexpr uint16_t kHostLength = 34;
static constexpr uint16_t kDeviceLength = 48;

struct Request {
    uint16_t vendor, product;
    uint8_t bmRequestType, bRequest;
    uint16_t wValue, wIndex, wLength;
    bool synchronous, rawBufferPresent, descriptorBufferPresent;
};

inline bool eligible(const Request &r) {
    // Class/interface IN GET_CUR, plus measured Kingcome-only OUT SET_CUR.
    // HP's measured interfaces are 1 and 3; Kingcome 2B7E:128F exposes one
    // video streaming interface (MI_00), expected at interface 1.
    const bool hpCamera = r.vendor == kHPVendor && r.product == kHPProduct &&
                          (r.wIndex == 1 || r.wIndex == 3);
    const bool kingcomeCamera = r.vendor == kKingcomeVendor &&
                                r.product == kKingcomeProduct && r.wIndex == 1;
    const bool supportedBuffer =
        (r.rawBufferPresent && !r.descriptorBufferPresent) ||
        (kingcomeCamera && !r.rawBufferPresent && r.descriptorBufferPresent);
    const bool probeOrCommit = r.wValue == 0x0100 || r.wValue == 0x0200;
    const bool getCur = (hpCamera || kingcomeCamera) && supportedBuffer &&
        r.bmRequestType == 0xA1 && r.bRequest == 0x81 &&
        r.wLength == kHostLength && r.synchronous && probeOrCommit;
    const bool kingcomeSetCur = kingcomeCamera && !r.rawBufferPresent &&
        r.descriptorBufferPresent && r.bmRequestType == 0x21 &&
        r.bRequest == 0x01 && r.wLength == kHostLength &&
        r.synchronous && probeOrCommit;
    return getCur || kingcomeSetCur;
}

inline bool safeTransfer(uint32_t actual, size_t capacity) {
    return actual == kDeviceLength && capacity >= kDeviceLength;
}

// Uses the existing UVCProbeFix Lilu plugin registration. No second kext.
bool start();
}
