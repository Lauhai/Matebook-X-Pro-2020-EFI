// UVC 1.50 GET_CUR length workaround for measured devices.
// Copyright (c) 2026 DNMTechLabs. All rights reserved.
// No changes to the frozen Lenovo 0.2.15 handshake region/policy.
#include "UVC15ProbeOverrun.hpp"

#ifdef UVCP_KERNEL_BUILD
#include <Headers/kern_api.hpp>
#include <Headers/kern_patcher.hpp>
#include <Headers/kern_util.hpp>
#include <IOKit/IOLib.h>
#include <IOKit/usb/IOUSBHostDevice.h>
#include <string.h>

#define MODULE_SHORT "uvcp"
namespace UVC15 {
namespace {
using RequestFunction = IOReturn (*)(IOUSBHostDevice *, IOService *,
    StandardUSB::DeviceRequest &, void *, IOMemoryDescriptor *,
    uint32_t &, IOUSBHostCompletion *, uint32_t);
static RequestFunction originalRequest {nullptr};
static bool routeInstalled {false};
static uint32_t kingcomeTraceCount {0};
static constexpr uint32_t kKingcomeTraceLimit = 32;
// Captured from successful Windows SET_CUR(PROBE/COMMIT) requests for
// Kingcome 2B7E:128F. The 14-byte UVC 1.5 suffix advertises 8-bit luma;
// all other extension fields in the measured request are zero.
static constexpr uint8_t kKingcomeSetCurExtension[kDeviceLength - kHostLength] {
    0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

// This is an exact C++ symbol selector, NOT a byte-pattern fallback.
// If missing / already patched / unsupported, HP mode remains inactive.
static const char kSymbol[] =
    "__ZN15IOUSBHostDevice21internalDeviceRequestEP9IOServiceRN11StandardUSB13DeviceRequestEPvP18IOMemoryDescriptorRjP19IOUSBHostCompletionj";
static const char *kPaths[] = {
    "/System/Library/Extensions/IOUSBHostFamily.kext/Contents/MacOS/IOUSBHostFamily"
};
static KernelPatcher::KextInfo hostInfo {
    "com.apple.iokit.IOUSBHostFamily", kPaths, arrsize(kPaths), {true}, {},
    KernelPatcher::KextInfo::Unloaded
};

// Deliberately reject any unknown prefix or already-routed function.
// It can disable HP recovery on a valid optimized build; never force-hook.
static bool verifiedPrologue(const uint8_t *p) {
    return p != nullptr && p[0] == 0x55 && p[1] == 0x48 &&
           p[2] == 0x89 && p[3] == 0xE5;
}

static bool supportedKernel() {
    const auto version = getKernelVersion();
    const auto minor = getKernelMinorVersion();
    // Sonoma is limited to the user's 14.7.x Darwin 23.6 ABI. Tahoe keeps
    // the original project's 25.6 gate. All other kernels fail closed.
    return (version == KernelVersion::Sonoma && minor == 6) ||
           (version == KernelVersion::Tahoe && minor == 6);
}

static IOReturn passThrough(IOUSBHostDevice *device, IOService *client,
                            StandardUSB::DeviceRequest &request, void *raw,
                            IOMemoryDescriptor *descriptor, uint32_t &transferred,
                            IOUSBHostCompletion *completion, uint32_t timeout,
                            bool trace, uint32_t traceSequence) {
    const IOReturn result = originalRequest(device, client, request, raw, descriptor,
                                             transferred, completion, timeout);
    if (trace) {
        SYSTRACE(MODULE_SHORT,
                 "Kingcome UVC result #%u: ret=%d done=%u",
                 traceSequence, result, transferred);
    }
    return result;
}

static IOReturn requestHook(IOUSBHostDevice *device, IOService *client,
                            StandardUSB::DeviceRequest &request,
                            void *raw, IOMemoryDescriptor *descriptor,
                            uint32_t &transferred, IOUSBHostCompletion *completion,
                            uint32_t timeout) {
    if (originalRequest == nullptr) return kIOReturnUnsupported;
    bool traceKingcome = false;
    uint32_t traceSequence = 0;
    const bool isKingcomeCur =
        (request.bmRequestType == 0xA1 && request.bRequest == 0x81) ||
        (request.bmRequestType == 0x21 && request.bRequest == 0x01);
    if (device != nullptr && isKingcomeCur &&
        (request.wValue == 0x0100 || request.wValue == 0x0200)) {
        const auto *observedIdentity = device->getDeviceDescriptor();
        if (observedIdentity != nullptr &&
            USBToHost16(observedIdentity->idVendor) == kKingcomeVendor &&
            USBToHost16(observedIdentity->idProduct) == kKingcomeProduct) {
            traceSequence = __atomic_fetch_add(&kingcomeTraceCount, 1, __ATOMIC_RELAXED);
            traceKingcome = traceSequence < kKingcomeTraceLimit;
            if (traceKingcome) {
                SYSTRACE(MODULE_SHORT,
                         "Kingcome UVC request #%u: bm=%02x b=%02x val=%04x idx=%04x len=%u raw=%d md=%d async=%d",
                         traceSequence, static_cast<unsigned>(request.bmRequestType),
                         static_cast<unsigned>(request.bRequest),
                         static_cast<unsigned>(request.wValue),
                         static_cast<unsigned>(request.wIndex),
                         static_cast<unsigned>(request.wLength), raw != nullptr,
                         descriptor != nullptr, completion != nullptr);
            }
        }
    }
    // Avoid descriptor reads and memory allocations for all unrelated USB IO.
    const bool isGetCur = request.bmRequestType == 0xA1 && request.bRequest == 0x81;
    const bool isSetCur = request.bmRequestType == 0x21 && request.bRequest == 0x01;
    if (device == nullptr || (!isGetCur && !isSetCur) ||
        request.wLength != kHostLength ||
        (request.wValue != 0x0100 && request.wValue != 0x0200) ||
        (request.wIndex != 1 && (isSetCur || request.wIndex != 3)) ||
        ((raw == nullptr) == (descriptor == nullptr)) || completion != nullptr) {
        return passThrough(device, client, request, raw, descriptor, transferred,
                           completion, timeout, traceKingcome, traceSequence);
    }

    const auto *identity = device->getDeviceDescriptor();
    Request view {};
    if (identity != nullptr) {
        view.vendor = USBToHost16(identity->idVendor);
        view.product = USBToHost16(identity->idProduct);
    }
    view.bmRequestType = request.bmRequestType;
    view.bRequest = request.bRequest;
    view.wValue = request.wValue;
    view.wIndex = request.wIndex;
    view.wLength = request.wLength;
    view.synchronous = completion == nullptr;
    view.rawBufferPresent = raw != nullptr;
    view.descriptorBufferPresent = descriptor != nullptr;
    if (!eligible(view)) {
        return passThrough(device, client, request, raw, descriptor, transferred,
                           completion, timeout, traceKingcome, traceSequence);
    }

    if (isSetCur) {
        // Windows captures show this Kingcome UVC 1.5 SET_CUR uses all 48
        // bytes. Sonoma supplies a 34-byte OUT descriptor; copy its request
        // fields unchanged and append only the measured 14-byte suffix.
        if (descriptor == nullptr || descriptor->getLength() < kHostLength ||
            (descriptor->getDirection() & kIODirectionOut) == 0) {
            return passThrough(device, client, request, raw, descriptor, transferred,
                               completion, timeout, traceKingcome, traceSequence);
        }
        void *expandedBytes = IOMalloc(kDeviceLength);
        if (expandedBytes == nullptr) {
            return passThrough(device, client, request, raw, descriptor, transferred,
                               completion, timeout, traceKingcome, traceSequence);
        }
        bzero(expandedBytes, kDeviceLength);
        const uint64_t copiedIn = descriptor->readBytes(0, expandedBytes, kHostLength);
        if (copiedIn != kHostLength) {
            bzero(expandedBytes, kDeviceLength);
            IOFree(expandedBytes, kDeviceLength);
            return passThrough(device, client, request, raw, descriptor, transferred,
                               completion, timeout, traceKingcome, traceSequence);
        }
        memcpy(static_cast<uint8_t *>(expandedBytes) + kHostLength,
               kKingcomeSetCurExtension, sizeof(kKingcomeSetCurExtension));
        StandardUSB::DeviceRequest enlarged = request;
        enlarged.wLength = kDeviceLength;
        uint32_t actual = 0;
        const IOReturn result = originalRequest(device, client, enlarged,
            expandedBytes, nullptr, actual, nullptr, timeout);
        SYSTRACE(MODULE_SHORT,
                 "Kingcome SET_CUR 34->48 result=%d actual=%u",
                 result, actual);
        bzero(expandedBytes, kDeviceLength);
        IOFree(expandedBytes, kDeviceLength);
        // For an OUT control transfer the USB completion status is the
        // authoritative success signal; some host paths leave the byte count
        // unset even when all requested data was acknowledged.
        if (result == kIOReturnSuccess) {
            transferred = kHostLength;
            return kIOReturnSuccess;
        }
        transferred = 0;
        return result != kIOReturnSuccess ? result : kIOReturnUnderrun;
    }

    if (descriptor != nullptr) {
        // Kingcome's Sonoma Probe path supplies a 34-byte input descriptor,
        // not the raw pointer used by the previously measured HP path.
        if (descriptor->getLength() < kHostLength ||
            (descriptor->getDirection() & kIODirectionIn) == 0) {
            return passThrough(device, client, request, raw, descriptor, transferred,
                               completion, timeout, traceKingcome, traceSequence);
        }
        // Use the already-established raw-buffer overload for the temporary
        // 48-byte transfer. The caller's descriptor remains owned/prepared by
        // Apple's request path; do not create or complete a nested descriptor.
        void *expandedBytes = IOMalloc(kDeviceLength);
        if (expandedBytes == nullptr) {
            return passThrough(device, client, request, raw, descriptor, transferred,
                               completion, timeout, traceKingcome, traceSequence);
        }
        bzero(expandedBytes, kDeviceLength);
        StandardUSB::DeviceRequest enlarged = request;
        enlarged.wLength = kDeviceLength;
        uint32_t actual = 0;
        const IOReturn result = originalRequest(device, client, enlarged,
            expandedBytes, nullptr, actual, nullptr, timeout);
        const bool transferComplete = result == kIOReturnSuccess &&
            safeTransfer(actual, kDeviceLength);
        bool copied = false;
        if (transferComplete) {
            // The intercepted descriptor is the active 34-byte IN buffer in
            // Apple's synchronous call. Copy only within its verified length.
            copied = descriptor->writeBytes(0, expandedBytes, kHostLength) == kHostLength;
        }
        SYSTRACE(MODULE_SHORT,
                 "Kingcome raw retry for descriptor 34->48 result=%d actual=%u complete=%d copied=%d",
                 result, actual, transferComplete, copied);
        bzero(expandedBytes, kDeviceLength);
        IOFree(expandedBytes, kDeviceLength);
        if (transferComplete && copied) {
            transferred = kHostLength;
            return kIOReturnSuccess;
        }
        transferred = 0;
        return result != kIOReturnSuccess ? result : kIOReturnUnderrun;
    }

    SYSTRACE(MODULE_SHORT, "Kingcome probe matched 34-byte recovery policy; retrying with 48 bytes");

    // Never issue a 48-byte transfer into Apple's 34-byte receive buffer.
    void *expanded = IOMalloc(kDeviceLength);
    if (expanded == nullptr) {
        return passThrough(device, client, request, raw, descriptor, transferred,
                           completion, timeout, traceKingcome, traceSequence);
    }
    bzero(expanded, kDeviceLength);
    StandardUSB::DeviceRequest enlarged = request;
    enlarged.wLength = kDeviceLength;
    uint32_t actual = 0;
    const IOReturn result = originalRequest(device, client, enlarged,
        expanded, nullptr, actual, nullptr, timeout);
    const bool complete = result == kIOReturnSuccess &&
                          safeTransfer(actual, kDeviceLength);
    SYSTRACE(MODULE_SHORT, "Kingcome 48-byte retry result=%d actual=%u complete=%d",
             result, actual, complete);
    if (complete) {
        memcpy(raw, expanded, kHostLength);
        transferred = kHostLength;
    } else {
        transferred = 0;
    }
    bzero(expanded, kDeviceLength);
    IOFree(expanded, kDeviceLength);
    if (complete) return kIOReturnSuccess;
    return result != kIOReturnSuccess ? result : kIOReturnUnderrun;
}

static void loaded(void *, KernelPatcher &patcher,
                   size_t index, mach_vm_address_t slide, size_t size) {
    SYSTRACE(MODULE_SHORT, "UVC1.5 IOUSBHostFamily callback: index=%lu size=%lu kernel=%u.%d",
             index, size, static_cast<unsigned>(getKernelVersion()), getKernelMinorVersion());
    if (routeInstalled) {
        SYSTRACE(MODULE_SHORT, "UVC1.5 callback skipped: route already installed");
        return;
    }
    if (size == 0) {
        SYSTRACE(MODULE_SHORT, "UVC1.5 callback skipped: target size is zero");
        return;
    }
    if (!supportedKernel()) {
        SYSTRACE(MODULE_SHORT, "UVC1.5 callback skipped: unsupported kernel %u.%d",
                 static_cast<unsigned>(getKernelVersion()), getKernelMinorVersion());
        return;
    }
    const auto target = patcher.solveSymbol(index, kSymbol, slide, size, false);
    if (target == 0) {
        patcher.clearError();
        SYSTRACE(MODULE_SHORT, "UVC1.5 symbol unavailable; not installing hook");
        return;
    }
    if (!verifiedPrologue(reinterpret_cast<const uint8_t *>(target))) {
        SYSTRACE(MODULE_SHORT, "UVC1.5 unverified/already-routed prologue; skipped");
        return;
    }
    KernelPatcher::RouteRequest route {kSymbol, requestHook, originalRequest};
    if (!patcher.routeMultiple(index, &route, 1, slide, size, true, false) ||
        originalRequest == nullptr) {
        patcher.clearError();
        SYSTRACE(MODULE_SHORT, "UVC1.5 route failed; recovery disabled");
        return;
    }
    routeInstalled = true;
    SYSTRACE(MODULE_SHORT, "UVC1.5 GET_CUR(34->48) route active for allowlisted VID/PID");
}
}

bool start() {
    SYSTRACE(MODULE_SHORT, "UVC1.5 start: kernel=%u.%d off=%d",
             static_cast<unsigned>(getKernelVersion()), getKernelMinorVersion(),
             checkKernelArgument("-uvc15off"));
    if (checkKernelArgument("-uvc15off")) {
        SYSTRACE(MODULE_SHORT, "UVC1.5 disabled by -uvc15off");
        return true;
    }
    if (!supportedKernel()) {
        SYSTRACE(MODULE_SHORT, "UVC1.5 unsupported kernel; callback not registered");
        return false;
    }
    const auto error = lilu.onKextLoad(&hostInfo, 1, loaded, nullptr);
    if (error != LiluAPI::Error::NoError) {
        SYSTRACE(MODULE_SHORT, "UVC1.5 failed to register IOUSBHostFamily (%d)",
                 static_cast<int>(error));
        return false;
    }
    SYSTRACE(MODULE_SHORT, "UVC1.5 registered IOUSBHostFamily callback");
    return true;
}
}
#else
// Host tests compile only the pure policy above.
#endif
